#!/usr/bin/env bash
set -euo pipefail
[[ "$EUID" == 0 ]] || { echo "Run this installer with sudo." >&2; exit 1; }
candidate="$(realpath -- "${1:?Usage: sudo scripts/install-existing.sh ./dist/neo-uptime}")"
binary=/usr/local/bin/neo-uptime
unit=neo-uptime.service
data="${NEO_DATA_DIR:-/var/lib/neo-uptime}"
health="${NEO_HEALTH_URL:-http://127.0.0.1:7788/api/health}"
backups="${NEO_BACKUP_DIR:-/var/backups}"
[[ -x "$candidate" && -x "$binary" && "$candidate" != "$binary" && -f "$data/neo-uptime.db" ]] || {
  echo "Expected an executable build and an existing official Neo Uptime installation." >&2; exit 1;
}
"$candidate" version | grep -Eq '^neo-uptime xdns-[0-9a-f]{12} linux/'
systemctl show -p ExecStart --value "$unit" | grep -Eq 'path=/usr/local/bin/neo-uptime([ ;]|$)'
systemctl is-active --quiet "$unit"
probe() {
  curl --silent --show-error --fail --max-time 3 "$health" |
    python3 -c 'import json, sys; sys.exit(0 if json.load(sys.stdin).get("ok") is True else 1)' 2>/dev/null
}
probe || { echo "The existing service does not answer on NEO_HEALTH_URL. Check the URL before updating." >&2; exit 1; }
umask 077
backup="$(mktemp -d "$backups/neo-uptime-before-xdns.XXXXXXXX")"
staged=""
stopped=0
swapped=0
success=0
finish() {
  local result=$?
  trap - EXIT INT TERM
  set +e
  [[ -z "$staged" ]] || rm -f -- "$staged"
  if [[ "$success" == 0 && "$stopped" == 1 ]]; then
    if [[ "$swapped" == 1 ]]; then
      local restore
      restore="$(mktemp "${binary}.restore.XXXXXXXX")"
      if install -m 0755 "$backup/neo-uptime" "$restore" && mv -fT -- "$restore" "$binary"; then
        echo "Original binary restored." >&2
      else
        echo "Automatic rollback failed. Original binary is at $backup/neo-uptime." >&2
      fi
    fi
    systemctl restart "$unit" || echo "Could not restart $unit." >&2
    echo "Backup directory: $backup" >&2
  fi
  exit "$result"
}
trap finish EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
install -m 0755 "$binary" "$backup/neo-uptime"
staged="$(mktemp "${binary}.xdns.XXXXXXXX")"
install -m 0755 "$candidate" "$staged"
stopped=1
systemctl stop "$unit"
tar --numeric-owner -czf "$backup/data.tar.gz" -C "$data" .
swapped=1
mv -fT -- "$staged" "$binary"
systemctl start "$unit"
for ((attempt = 0; attempt < 20; attempt++)); do
  if systemctl is-active --quiet "$unit" && probe; then
    success=1
    printf 'Neo Uptime is healthy. Backup: %s\n' "$backup"
    "$binary" version
    exit 0
  fi
  sleep 1
done
echo "The updated service failed its health check." >&2
exit 1
